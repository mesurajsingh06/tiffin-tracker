# Tiffin Tracker

A mobile-first PWA to track daily tiffin meals, running balance, and vendor payments. All data stays in your browser's LocalStorage — no backend, no accounts.

## Files
- `index.html` — layout + Tailwind CDN
- `app.js` — all logic (LocalStorage CRUD, balance math, rendering, CSV export)
- `manifest.json` — PWA metadata
- `sw.js` — offline caching service worker
- `icons/icon-192.png`, `icons/icon-512.png` — app icons

## Deploy on GitHub Pages (free)
1. Create a new GitHub repo (e.g. `tiffin-tracker`) and push these files to it, keeping them at the repo root (don't nest them in a subfolder).
2. In the repo, go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to `Deploy from a branch`, branch `main`, folder `/ (root)`. Save.
4. Wait a minute, then open the URL GitHub gives you (looks like `https://<username>.github.io/tiffin-tracker/`).

All paths in the app are relative (`./app.js`, `./icons/...`), so it works whether it's served from the repo root or a subpath — no code changes needed.

## Install on your phone
- **Android (Chrome):** open the URL → menu (⋮) → **Add to Home screen** / **Install app**.
- **iPhone (Safari):** open the URL → Share icon → **Add to Home Screen**.

Once installed, the service worker caches the app shell so it keeps working with no signal — your data was always local anyway.

## Notes on a couple of implementation choices
- **Icons are inline SVG, not the FontAwesome CDN.** An external icon-font request would fail once you're offline and defeats the point of a PWA; inline SVGs are already "in" the HTML, so they just work.
- **Font is the OS system-font stack**, not a Google Fonts import, for the same offline reason.
- **One entry per date.** Saving a day upserts that date's lunch/dinner; logging a payment upserts (and accumulates onto) that date's payment. `dailyTotal` is meal cost only (`lunch + dinner`); the running balance is `Σ dailyTotal − Σ payment` across all entries.
- Tap the 🗑 icon on any history row to delete a bad entry.
